pub mod virtual_machine;
pub mod objects;
pub mod ffi;
pub mod stdlib;
